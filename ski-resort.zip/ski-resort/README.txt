Ski Resort
A free 3D model kit from Shuriken Studio
https://shuriken.studio/kits/ski-resort

A free low-poly ski resort kit for Roblox Studio: 25 matching GLB models for a ski, snowboard or winter sports game. The resort has a timber ski lodge, a holiday chalet, a ski rental shop, a mountain rescue hut, a lift ticket booth and a lodge lounge with a big stone fireplace. Players get up the mountain on chairlift pieces or a gondola cable car, and come down a ski jump, a snowboard park with rails and a half-pipe, a bobsled run or a snow tubing lane. Lay out races with a start gate, slalom gates, piste markers and snow fences, and dress the slopes with snow cannons. Drive a snowmobile or a snow groomer, relax in a hot tub or on a mountain terrace, and play curling or ice hockey. A skier and a snowboarder are ready as NPCs or statues. Doors, seats and gates are separate parts, and every model is sized in studs.

25 models, as GLB (glTF 2.0) files:
  timber-ski-lodge.glb         Timber Ski Lodge  https://shuriken.studio/models/buildings/timber-ski-lodge
  alpine-ski-chalet.glb        Alpine Ski Chalet  https://shuriken.studio/models/buildings/alpine-ski-chalet
  wooden-ski-jump.glb          Wooden Ski Jump  https://shuriken.studio/models/scenery/wooden-ski-jump
  ski-resort-snow-groomer.glb  Ski Resort Snow Groomer  https://shuriken.studio/models/vehicles/ski-resort-snow-groomer
  sporty-snowmobile.glb        Sporty Snowmobile  https://shuriken.studio/models/vehicles/sporty-snowmobile
  low-poly-skier.glb           Low-Poly Skier  https://shuriken.studio/models/characters/low-poly-skier
  ski-rental-shop.glb          Ski Rental Shop  https://shuriken.studio/models/buildings/ski-rental-shop
  ice-hockey-set.glb           Ice Hockey Set  https://shuriken.studio/models/props/ice-hockey-set
  lift-ticket-booth.glb        Lift Ticket Booth  https://shuriken.studio/models/props/lift-ticket-booth
  ski-resort-terrace.glb       Ski Resort Terrace  https://shuriken.studio/models/props/ski-resort-terrace
  ski-gondola-station.glb      Ski Gondola Station  https://shuriken.studio/models/vehicles/ski-gondola-station
  banked-bobsled-run.glb       Banked Bobsled Run  https://shuriken.studio/models/scenery/banked-bobsled-run
  ski-resort-chairlift.glb     Ski Resort Chairlift  https://shuriken.studio/models/props/ski-resort-chairlift
  mountain-rescue-hut.glb      Mountain Rescue Hut  https://shuriken.studio/models/buildings/mountain-rescue-hut
  snow-tubing-lane.glb         Snow Tubing Lane  https://shuriken.studio/models/scenery/snow-tubing-lane
  piste-marker-set.glb         Piste Marker Set  https://shuriken.studio/models/props/piste-marker-set
  ski-lodge-lounge.glb         Ski Lodge Lounge  https://shuriken.studio/models/furniture/ski-lodge-lounge
  curling-rink-set.glb         Curling Rink Set  https://shuriken.studio/models/props/curling-rink-set
  ski-race-start-gate.glb      Ski Race Start Gate  https://shuriken.studio/models/props/ski-race-start-gate
  ski-resort-hot-tub-deck.glb  Ski Resort Hot Tub Deck  https://shuriken.studio/models/props/ski-resort-hot-tub-deck
  snow-cannon-set.glb          Snow Cannon Set  https://shuriken.studio/models/props/snow-cannon-set
  snowboard-park-set.glb       Snowboard Park Set  https://shuriken.studio/models/kits/snowboard-park-set
  ski-resort-snow-fences.glb   Ski Resort Snow Fences  https://shuriken.studio/models/props/ski-resort-snow-fences
  low-poly-snowboarder.glb     Low-Poly Snowboarder  https://shuriken.studio/models/characters/low-poly-snowboarder
  slalom-gates-set.glb         Slalom Gates Set  https://shuriken.studio/models/props/slalom-gates-set

Using them
  Roblox Studio: Import 3D, choose a GLB, insert.
  Blender: File > Import > glTF 2.0.
  Unity, Godot, Unreal, three.js: import directly or through glTF.

Terms
  Free to use in any project, commercial games included: no account, no fee and no credit needed.
  Don't sell or share the model files themselves, alone or as a pack. They come as they are, with
  no warranty. LICENSE.txt has the short version; the full license is at https://shuriken.studio/legal/models
